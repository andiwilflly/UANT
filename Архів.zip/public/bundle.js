
(function(l, r) { if (l.getElementById('livereloadscript')) return; r = l.createElement('script'); r.async = 1; r.src = '//' + (window.location.host || 'localhost').split(':')[0] + ':35729/livereload.js?snipver=1'; r.id = 'livereloadscript'; l.head.appendChild(r) })(window.document);
var app = (function () {
    'use strict';

    function noop() { }
    const identity = x => x;
    function add_location(element, file, line, column, char) {
        element.__svelte_meta = {
            loc: { file, line, column, char }
        };
    }
    function run(fn) {
        return fn();
    }
    function blank_object() {
        return Object.create(null);
    }
    function run_all(fns) {
        fns.forEach(run);
    }
    function is_function(thing) {
        return typeof thing === 'function';
    }
    function safe_not_equal(a, b) {
        return a != a ? b == b : a !== b || ((a && typeof a === 'object') || typeof a === 'function');
    }
    function validate_store(store, name) {
        if (!store || typeof store.subscribe !== 'function') {
            throw new Error(`'${name}' is not a store with a 'subscribe' method`);
        }
    }
    function subscribe(store, callback) {
        const unsub = store.subscribe(callback);
        return unsub.unsubscribe ? () => unsub.unsubscribe() : unsub;
    }
    function component_subscribe(component, store, callback) {
        component.$$.on_destroy.push(subscribe(store, callback));
    }
    function null_to_empty(value) {
        return value == null ? '' : value;
    }

    const is_client = typeof window !== 'undefined';
    let now = is_client
        ? () => window.performance.now()
        : () => Date.now();
    let raf = is_client ? cb => requestAnimationFrame(cb) : noop;

    const tasks = new Set();
    let running = false;
    function run_tasks() {
        tasks.forEach(task => {
            if (!task[0](now())) {
                tasks.delete(task);
                task[1]();
            }
        });
        running = tasks.size > 0;
        if (running)
            raf(run_tasks);
    }
    function loop(fn) {
        let task;
        if (!running) {
            running = true;
            raf(run_tasks);
        }
        return {
            promise: new Promise(fulfil => {
                tasks.add(task = [fn, fulfil]);
            }),
            abort() {
                tasks.delete(task);
            }
        };
    }

    function append(target, node) {
        target.appendChild(node);
    }
    function insert(target, node, anchor) {
        target.insertBefore(node, anchor || null);
    }
    function detach(node) {
        node.parentNode.removeChild(node);
    }
    function element(name) {
        return document.createElement(name);
    }
    function text(data) {
        return document.createTextNode(data);
    }
    function space() {
        return text(' ');
    }
    function listen(node, event, handler, options) {
        node.addEventListener(event, handler, options);
        return () => node.removeEventListener(event, handler, options);
    }
    function attr(node, attribute, value) {
        if (value == null)
            node.removeAttribute(attribute);
        else
            node.setAttribute(attribute, value);
    }
    function to_number(value) {
        return value === '' ? undefined : +value;
    }
    function children(element) {
        return Array.from(element.childNodes);
    }
    function set_input_value(input, value) {
        if (value != null || input.value) {
            input.value = value;
        }
    }
    function set_style(node, key, value, important) {
        node.style.setProperty(key, value, important ? 'important' : '');
    }
    function custom_event(type, detail) {
        const e = document.createEvent('CustomEvent');
        e.initCustomEvent(type, false, false, detail);
        return e;
    }

    let stylesheet;
    let active = 0;
    let current_rules = {};
    // https://github.com/darkskyapp/string-hash/blob/master/index.js
    function hash(str) {
        let hash = 5381;
        let i = str.length;
        while (i--)
            hash = ((hash << 5) - hash) ^ str.charCodeAt(i);
        return hash >>> 0;
    }
    function create_rule(node, a, b, duration, delay, ease, fn, uid = 0) {
        const step = 16.666 / duration;
        let keyframes = '{\n';
        for (let p = 0; p <= 1; p += step) {
            const t = a + (b - a) * ease(p);
            keyframes += p * 100 + `%{${fn(t, 1 - t)}}\n`;
        }
        const rule = keyframes + `100% {${fn(b, 1 - b)}}\n}`;
        const name = `__svelte_${hash(rule)}_${uid}`;
        if (!current_rules[name]) {
            if (!stylesheet) {
                const style = element('style');
                document.head.appendChild(style);
                stylesheet = style.sheet;
            }
            current_rules[name] = true;
            stylesheet.insertRule(`@keyframes ${name} ${rule}`, stylesheet.cssRules.length);
        }
        const animation = node.style.animation || '';
        node.style.animation = `${animation ? `${animation}, ` : ``}${name} ${duration}ms linear ${delay}ms 1 both`;
        active += 1;
        return name;
    }
    function delete_rule(node, name) {
        node.style.animation = (node.style.animation || '')
            .split(', ')
            .filter(name
            ? anim => anim.indexOf(name) < 0 // remove specific animation
            : anim => anim.indexOf('__svelte') === -1 // remove all Svelte animations
        )
            .join(', ');
        if (name && !--active)
            clear_rules();
    }
    function clear_rules() {
        raf(() => {
            if (active)
                return;
            let i = stylesheet.cssRules.length;
            while (i--)
                stylesheet.deleteRule(i);
            current_rules = {};
        });
    }

    let current_component;
    function set_current_component(component) {
        current_component = component;
    }
    function get_current_component() {
        if (!current_component)
            throw new Error(`Function called outside component initialization`);
        return current_component;
    }
    function onMount(fn) {
        get_current_component().$$.on_mount.push(fn);
    }

    const dirty_components = [];
    const binding_callbacks = [];
    const render_callbacks = [];
    const flush_callbacks = [];
    const resolved_promise = Promise.resolve();
    let update_scheduled = false;
    function schedule_update() {
        if (!update_scheduled) {
            update_scheduled = true;
            resolved_promise.then(flush);
        }
    }
    function add_render_callback(fn) {
        render_callbacks.push(fn);
    }
    function flush() {
        const seen_callbacks = new Set();
        do {
            // first, call beforeUpdate functions
            // and update components
            while (dirty_components.length) {
                const component = dirty_components.shift();
                set_current_component(component);
                update(component.$$);
            }
            while (binding_callbacks.length)
                binding_callbacks.pop()();
            // then, once components are updated, call
            // afterUpdate functions. This may cause
            // subsequent updates...
            for (let i = 0; i < render_callbacks.length; i += 1) {
                const callback = render_callbacks[i];
                if (!seen_callbacks.has(callback)) {
                    callback();
                    // ...so guard against infinite loops
                    seen_callbacks.add(callback);
                }
            }
            render_callbacks.length = 0;
        } while (dirty_components.length);
        while (flush_callbacks.length) {
            flush_callbacks.pop()();
        }
        update_scheduled = false;
    }
    function update($$) {
        if ($$.fragment) {
            $$.update($$.dirty);
            run_all($$.before_update);
            $$.fragment.p($$.dirty, $$.ctx);
            $$.dirty = null;
            $$.after_update.forEach(add_render_callback);
        }
    }

    let promise;
    function wait() {
        if (!promise) {
            promise = Promise.resolve();
            promise.then(() => {
                promise = null;
            });
        }
        return promise;
    }
    function dispatch(node, direction, kind) {
        node.dispatchEvent(custom_event(`${direction ? 'intro' : 'outro'}${kind}`));
    }
    const outroing = new Set();
    let outros;
    function group_outros() {
        outros = {
            r: 0,
            c: [],
            p: outros // parent group
        };
    }
    function check_outros() {
        if (!outros.r) {
            run_all(outros.c);
        }
        outros = outros.p;
    }
    function transition_in(block, local) {
        if (block && block.i) {
            outroing.delete(block);
            block.i(local);
        }
    }
    function transition_out(block, local, detach, callback) {
        if (block && block.o) {
            if (outroing.has(block))
                return;
            outroing.add(block);
            outros.c.push(() => {
                outroing.delete(block);
                if (callback) {
                    if (detach)
                        block.d(1);
                    callback();
                }
            });
            block.o(local);
        }
    }
    const null_transition = { duration: 0 };
    function create_bidirectional_transition(node, fn, params, intro) {
        let config = fn(node, params);
        let t = intro ? 0 : 1;
        let running_program = null;
        let pending_program = null;
        let animation_name = null;
        function clear_animation() {
            if (animation_name)
                delete_rule(node, animation_name);
        }
        function init(program, duration) {
            const d = program.b - t;
            duration *= Math.abs(d);
            return {
                a: t,
                b: program.b,
                d,
                duration,
                start: program.start,
                end: program.start + duration,
                group: program.group
            };
        }
        function go(b) {
            const { delay = 0, duration = 300, easing = identity, tick = noop, css } = config || null_transition;
            const program = {
                start: now() + delay,
                b
            };
            if (!b) {
                // @ts-ignore todo: improve typings
                program.group = outros;
                outros.r += 1;
            }
            if (running_program) {
                pending_program = program;
            }
            else {
                // if this is an intro, and there's a delay, we need to do
                // an initial tick and/or apply CSS animation immediately
                if (css) {
                    clear_animation();
                    animation_name = create_rule(node, t, b, duration, delay, easing, css);
                }
                if (b)
                    tick(0, 1);
                running_program = init(program, duration);
                add_render_callback(() => dispatch(node, b, 'start'));
                loop(now => {
                    if (pending_program && now > pending_program.start) {
                        running_program = init(pending_program, duration);
                        pending_program = null;
                        dispatch(node, running_program.b, 'start');
                        if (css) {
                            clear_animation();
                            animation_name = create_rule(node, t, running_program.b, running_program.duration, 0, easing, config.css);
                        }
                    }
                    if (running_program) {
                        if (now >= running_program.end) {
                            tick(t = running_program.b, 1 - t);
                            dispatch(node, running_program.b, 'end');
                            if (!pending_program) {
                                // we're done
                                if (running_program.b) {
                                    // intro — we can tidy up immediately
                                    clear_animation();
                                }
                                else {
                                    // outro — needs to be coordinated
                                    if (!--running_program.group.r)
                                        run_all(running_program.group.c);
                                }
                            }
                            running_program = null;
                        }
                        else if (now >= running_program.start) {
                            const p = now - running_program.start;
                            t = running_program.a + running_program.d * easing(p / running_program.duration);
                            tick(t, 1 - t);
                        }
                    }
                    return !!(running_program || pending_program);
                });
            }
        }
        return {
            run(b) {
                if (is_function(config)) {
                    wait().then(() => {
                        // @ts-ignore
                        config = config();
                        go(b);
                    });
                }
                else {
                    go(b);
                }
            },
            end() {
                clear_animation();
                running_program = pending_program = null;
            }
        };
    }

    function destroy_block(block, lookup) {
        block.d(1);
        lookup.delete(block.key);
    }
    function update_keyed_each(old_blocks, changed, get_key, dynamic, ctx, list, lookup, node, destroy, create_each_block, next, get_context) {
        let o = old_blocks.length;
        let n = list.length;
        let i = o;
        const old_indexes = {};
        while (i--)
            old_indexes[old_blocks[i].key] = i;
        const new_blocks = [];
        const new_lookup = new Map();
        const deltas = new Map();
        i = n;
        while (i--) {
            const child_ctx = get_context(ctx, list, i);
            const key = get_key(child_ctx);
            let block = lookup.get(key);
            if (!block) {
                block = create_each_block(key, child_ctx);
                block.c();
            }
            else if (dynamic) {
                block.p(changed, child_ctx);
            }
            new_lookup.set(key, new_blocks[i] = block);
            if (key in old_indexes)
                deltas.set(key, Math.abs(i - old_indexes[key]));
        }
        const will_move = new Set();
        const did_move = new Set();
        function insert(block) {
            transition_in(block, 1);
            block.m(node, next);
            lookup.set(block.key, block);
            next = block.first;
            n--;
        }
        while (o && n) {
            const new_block = new_blocks[n - 1];
            const old_block = old_blocks[o - 1];
            const new_key = new_block.key;
            const old_key = old_block.key;
            if (new_block === old_block) {
                // do nothing
                next = new_block.first;
                o--;
                n--;
            }
            else if (!new_lookup.has(old_key)) {
                // remove old block
                destroy(old_block, lookup);
                o--;
            }
            else if (!lookup.has(new_key) || will_move.has(new_key)) {
                insert(new_block);
            }
            else if (did_move.has(old_key)) {
                o--;
            }
            else if (deltas.get(new_key) > deltas.get(old_key)) {
                did_move.add(new_key);
                insert(new_block);
            }
            else {
                will_move.add(old_key);
                o--;
            }
        }
        while (o--) {
            const old_block = old_blocks[o];
            if (!new_lookup.has(old_block.key))
                destroy(old_block, lookup);
        }
        while (n)
            insert(new_blocks[n - 1]);
        return new_blocks;
    }
    function mount_component(component, target, anchor) {
        const { fragment, on_mount, on_destroy, after_update } = component.$$;
        fragment.m(target, anchor);
        // onMount happens before the initial afterUpdate
        add_render_callback(() => {
            const new_on_destroy = on_mount.map(run).filter(is_function);
            if (on_destroy) {
                on_destroy.push(...new_on_destroy);
            }
            else {
                // Edge case - component was destroyed immediately,
                // most likely as a result of a binding initialising
                run_all(new_on_destroy);
            }
            component.$$.on_mount = [];
        });
        after_update.forEach(add_render_callback);
    }
    function destroy_component(component, detaching) {
        if (component.$$.fragment) {
            run_all(component.$$.on_destroy);
            component.$$.fragment.d(detaching);
            // TODO null out other refs, including component.$$ (but need to
            // preserve final state?)
            component.$$.on_destroy = component.$$.fragment = null;
            component.$$.ctx = {};
        }
    }
    function make_dirty(component, key) {
        if (!component.$$.dirty) {
            dirty_components.push(component);
            schedule_update();
            component.$$.dirty = blank_object();
        }
        component.$$.dirty[key] = true;
    }
    function init(component, options, instance, create_fragment, not_equal, prop_names) {
        const parent_component = current_component;
        set_current_component(component);
        const props = options.props || {};
        const $$ = component.$$ = {
            fragment: null,
            ctx: null,
            // state
            props: prop_names,
            update: noop,
            not_equal,
            bound: blank_object(),
            // lifecycle
            on_mount: [],
            on_destroy: [],
            before_update: [],
            after_update: [],
            context: new Map(parent_component ? parent_component.$$.context : []),
            // everything else
            callbacks: blank_object(),
            dirty: null
        };
        let ready = false;
        $$.ctx = instance
            ? instance(component, props, (key, ret, value = ret) => {
                if ($$.ctx && not_equal($$.ctx[key], $$.ctx[key] = value)) {
                    if ($$.bound[key])
                        $$.bound[key](value);
                    if (ready)
                        make_dirty(component, key);
                }
                return ret;
            })
            : props;
        $$.update();
        ready = true;
        run_all($$.before_update);
        $$.fragment = create_fragment($$.ctx);
        if (options.target) {
            if (options.hydrate) {
                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                $$.fragment.l(children(options.target));
            }
            else {
                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                $$.fragment.c();
            }
            if (options.intro)
                transition_in(component.$$.fragment);
            mount_component(component, options.target, options.anchor);
            flush();
        }
        set_current_component(parent_component);
    }
    class SvelteComponent {
        $destroy() {
            destroy_component(this, 1);
            this.$destroy = noop;
        }
        $on(type, callback) {
            const callbacks = (this.$$.callbacks[type] || (this.$$.callbacks[type] = []));
            callbacks.push(callback);
            return () => {
                const index = callbacks.indexOf(callback);
                if (index !== -1)
                    callbacks.splice(index, 1);
            };
        }
        $set() {
            // overridden by instance, if it has props
        }
    }

    function dispatch_dev(type, detail) {
        document.dispatchEvent(custom_event(type, detail));
    }
    function append_dev(target, node) {
        dispatch_dev("SvelteDOMInsert", { target, node });
        append(target, node);
    }
    function insert_dev(target, node, anchor) {
        dispatch_dev("SvelteDOMInsert", { target, node, anchor });
        insert(target, node, anchor);
    }
    function detach_dev(node) {
        dispatch_dev("SvelteDOMRemove", { node });
        detach(node);
    }
    function listen_dev(node, event, handler, options, has_prevent_default, has_stop_propagation) {
        const modifiers = options === true ? ["capture"] : options ? Array.from(Object.keys(options)) : [];
        if (has_prevent_default)
            modifiers.push('preventDefault');
        if (has_stop_propagation)
            modifiers.push('stopPropagation');
        dispatch_dev("SvelteDOMAddEventListener", { node, event, handler, modifiers });
        const dispose = listen(node, event, handler, options);
        return () => {
            dispatch_dev("SvelteDOMRemoveEventListener", { node, event, handler, modifiers });
            dispose();
        };
    }
    function attr_dev(node, attribute, value) {
        attr(node, attribute, value);
        if (value == null)
            dispatch_dev("SvelteDOMRemoveAttribute", { node, attribute });
        else
            dispatch_dev("SvelteDOMSetAttribute", { node, attribute, value });
    }
    function prop_dev(node, property, value) {
        node[property] = value;
        dispatch_dev("SvelteDOMSetProperty", { node, property, value });
    }
    function set_data_dev(text, data) {
        data = '' + data;
        if (text.data === data)
            return;
        dispatch_dev("SvelteDOMSetData", { node: text, data });
        text.data = data;
    }
    class SvelteComponentDev extends SvelteComponent {
        constructor(options) {
            if (!options || (!options.target && !options.$$inline)) {
                throw new Error(`'target' is a required option`);
            }
            super();
        }
        $destroy() {
            super.$destroy();
            this.$destroy = () => {
                console.warn(`Component was already destroyed`); // eslint-disable-line no-console
            };
        }
    }

    const subscriber_queue = [];
    /**
     * Create a `Writable` store that allows both updating and reading by subscription.
     * @param {*=}value initial value
     * @param {StartStopNotifier=}start start and stop notifications for subscriptions
     */
    function writable(value, start = noop) {
        let stop;
        const subscribers = [];
        function set(new_value) {
            if (safe_not_equal(value, new_value)) {
                value = new_value;
                if (stop) { // store is ready
                    const run_queue = !subscriber_queue.length;
                    for (let i = 0; i < subscribers.length; i += 1) {
                        const s = subscribers[i];
                        s[1]();
                        subscriber_queue.push(s, value);
                    }
                    if (run_queue) {
                        for (let i = 0; i < subscriber_queue.length; i += 2) {
                            subscriber_queue[i][0](subscriber_queue[i + 1]);
                        }
                        subscriber_queue.length = 0;
                    }
                }
            }
        }
        function update(fn) {
            set(fn(value));
        }
        function subscribe(run, invalidate = noop) {
            const subscriber = [run, invalidate];
            subscribers.push(subscriber);
            if (subscribers.length === 1) {
                stop = start(set) || noop;
            }
            run(value);
            return () => {
                const index = subscribers.indexOf(subscriber);
                if (index !== -1) {
                    subscribers.splice(index, 1);
                }
                if (subscribers.length === 0) {
                    stop();
                    stop = null;
                }
            };
        }
        return { set, update, subscribe };
    }

    function User() {
        const { subscribe, set, update } = writable(null);

        return {
            subscribe,
            signIn: (changes= {})=> update(user => changes),
            signOut: ()=> update(user => null)
        };
    }

    const user = User();

    function Players() {
        const { subscribe, set, update } = writable({
            all: [],
            selected: null
        });

        return {
            subscribe,
            add: (player= {})=> update(players => ({
                all: [...players.all, player],
                selected: players.selected
            })),
            delete: (firebaseId)=>  update(players => ({
                all: players.all.filter(player => player.firebaseId !== firebaseId),
                selected: players.selected
            })),
            select: (playerId)=> update(players => ({
                all: players.all,
                selected: playerId
            })),
            updatePlayer: (changes= {})=> update(players => ({
                all: players.all.map(player => player.firebaseId === changes.firebaseId ? { ...player, ...changes } : player),
                selected: players.selected
            }))
        };
    }

    var players = Players();

    const db = window.firebase.firestore();


    const FIRESTORE = {
        players: db.collection('players')
    };

    /* src/components/PlayersTable.component.svelte generated by Svelte v3.12.1 */

    const file = "src/components/PlayersTable.component.svelte";

    function get_each_context(ctx, list, i) {
    	const child_ctx = Object.create(ctx);
    	child_ctx.player = list[i];
    	return child_ctx;
    }

    // (38:8) { #each $players.all as player (player.firebaseId) }
    function create_each_block(key_1, ctx) {
    	var div3, a, t0_value = ctx.player.name + "", t0, t1, t2_value = ctx.player.age + "", t2, a_href_value, t3, div2, div0, p0, t4, span0, t5_value = ctx.formatter.format(ctx.player.value) + "", t5, t6, t7, p1, t8, span1, t9_value = ctx.formatter.format(ctx.player.wage) + "", t9, t10, t11, div1, t12;

    	const block = {
    		key: key_1,

    		first: null,

    		c: function create() {
    			div3 = element("div");
    			a = element("a");
    			t0 = text(t0_value);
    			t1 = text(", ");
    			t2 = text(t2_value);
    			t3 = space();
    			div2 = element("div");
    			div0 = element("div");
    			p0 = element("p");
    			t4 = text("Вартість ");
    			span0 = element("span");
    			t5 = text(t5_value);
    			t6 = text(" грн.");
    			t7 = space();
    			p1 = element("p");
    			t8 = text("Зарплатня ");
    			span1 = element("span");
    			t9 = text(t9_value);
    			t10 = text(" грн.");
    			t11 = space();
    			div1 = element("div");
    			t12 = space();
    			attr_dev(a, "class", "player-name svelte-nshvhj");
    			attr_dev(a, "target", "_blank");
    			attr_dev(a, "href", a_href_value = `http://sokker.org/player/PID/${ctx.player._id}`);
    			add_location(a, file, 39, 16, 1170);
    			set_style(span0, "color", "#46a146");
    			add_location(span0, file, 45, 36, 1462);
    			add_location(p0, file, 45, 24, 1450);
    			set_style(span1, "color", "#46a146");
    			add_location(span1, file, 46, 37, 1579);
    			add_location(p1, file, 46, 24, 1566);
    			attr_dev(div0, "class", "player-info svelte-nshvhj");
    			add_location(div0, file, 44, 20, 1400);
    			attr_dev(div1, "class", "player-stats svelte-nshvhj");
    			add_location(div1, file, 48, 20, 1705);
    			attr_dev(div2, "class", "player-inner svelte-nshvhj");
    			add_location(div2, file, 43, 16, 1353);
    			attr_dev(div3, "class", "player svelte-nshvhj");
    			add_location(div3, file, 38, 12, 1133);
    			this.first = div3;
    		},

    		m: function mount(target, anchor) {
    			insert_dev(target, div3, anchor);
    			append_dev(div3, a);
    			append_dev(a, t0);
    			append_dev(a, t1);
    			append_dev(a, t2);
    			append_dev(div3, t3);
    			append_dev(div3, div2);
    			append_dev(div2, div0);
    			append_dev(div0, p0);
    			append_dev(p0, t4);
    			append_dev(p0, span0);
    			append_dev(span0, t5);
    			append_dev(p0, t6);
    			append_dev(div0, t7);
    			append_dev(div0, p1);
    			append_dev(p1, t8);
    			append_dev(p1, span1);
    			append_dev(span1, t9);
    			append_dev(p1, t10);
    			append_dev(div2, t11);
    			append_dev(div2, div1);
    			append_dev(div3, t12);
    		},

    		p: function update(changed, ctx) {
    			if ((changed.$players) && t0_value !== (t0_value = ctx.player.name + "")) {
    				set_data_dev(t0, t0_value);
    			}

    			if ((changed.$players) && t2_value !== (t2_value = ctx.player.age + "")) {
    				set_data_dev(t2, t2_value);
    			}

    			if ((changed.$players) && a_href_value !== (a_href_value = `http://sokker.org/player/PID/${ctx.player._id}`)) {
    				attr_dev(a, "href", a_href_value);
    			}

    			if ((changed.$players) && t5_value !== (t5_value = ctx.formatter.format(ctx.player.value) + "")) {
    				set_data_dev(t5, t5_value);
    			}

    			if ((changed.$players) && t9_value !== (t9_value = ctx.formatter.format(ctx.player.wage) + "")) {
    				set_data_dev(t9, t9_value);
    			}
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach_dev(div3);
    			}
    		}
    	};
    	dispatch_dev("SvelteRegisterBlock", { block, id: create_each_block.name, type: "each", source: "(38:8) { each_1 $players.all as player (player.firebaseId) }", ctx });
    	return block;
    }

    function create_fragment(ctx) {
    	var div1, button0, t1, button1, t3, br0, t4, br1, t5, div0, each_blocks = [], each_1_lookup = new Map(), dispose;

    	let each_value = ctx.$players.all;

    	const get_key = ctx => ctx.player.firebaseId;

    	for (let i = 0; i < each_value.length; i += 1) {
    		let child_ctx = get_each_context(ctx, each_value, i);
    		let key = get_key(child_ctx);
    		each_1_lookup.set(key, each_blocks[i] = create_each_block(key, child_ctx));
    	}

    	const block = {
    		c: function create() {
    			div1 = element("div");
    			button0 = element("button");
    			button0.textContent = "+ Add new player";
    			t1 = text("    \n    ");
    			button1 = element("button");
    			button1.textContent = "LogOut";
    			t3 = space();
    			br0 = element("br");
    			t4 = space();
    			br1 = element("br");
    			t5 = space();
    			div0 = element("div");

    			for (let i = 0; i < each_blocks.length; i += 1) {
    				each_blocks[i].c();
    			}
    			add_location(button0, file, 31, 4, 829);
    			add_location(button1, file, 32, 4, 929);
    			add_location(br0, file, 33, 4, 1006);
    			add_location(br1, file, 34, 4, 1016);
    			attr_dev(div0, "class", "players-list-inner svelte-nshvhj");
    			add_location(div0, file, 36, 4, 1027);
    			attr_dev(div1, "class", "players-table");
    			add_location(div1, file, 30, 0, 788);

    			dispose = [
    				listen_dev(button0, "click", ctx.click_handler),
    				listen_dev(button1, "click", click_handler_1)
    			];
    		},

    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			insert_dev(target, div1, anchor);
    			append_dev(div1, button0);
    			append_dev(div1, t1);
    			append_dev(div1, button1);
    			append_dev(div1, t3);
    			append_dev(div1, br0);
    			append_dev(div1, t4);
    			append_dev(div1, br1);
    			append_dev(div1, t5);
    			append_dev(div1, div0);

    			for (let i = 0; i < each_blocks.length; i += 1) {
    				each_blocks[i].m(div0, null);
    			}
    		},

    		p: function update(changed, ctx) {
    			const each_value = ctx.$players.all;
    			each_blocks = update_keyed_each(each_blocks, changed, get_key, 1, ctx, each_value, each_1_lookup, div0, destroy_block, create_each_block, null, get_each_context);
    		},

    		i: noop,
    		o: noop,

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach_dev(div1);
    			}

    			for (let i = 0; i < each_blocks.length; i += 1) {
    				each_blocks[i].d();
    			}

    			run_all(dispose);
    		}
    	};
    	dispatch_dev("SvelteRegisterBlock", { block, id: create_fragment.name, type: "component", source: "", ctx });
    	return block;
    }

    const click_handler_1 = () => window.firebase.auth().signOut();

    function instance($$self, $$props, $$invalidate) {
    	let $players;

    	validate_store(players, 'players');
    	component_subscribe($$self, players, $$value => { $players = $$value; $$invalidate('$players', $players); });

    	


        FIRESTORE.players.get().then((querySnapshot)=> {
            querySnapshot.forEach((doc)=> {
                players.add({ ...doc.data(), firebaseId: doc.id });
            });
        });

        const formatter = new Intl.NumberFormat("ua", { });

    	const click_handler = () => players.select('new');

    	$$self.$capture_state = () => {
    		return {};
    	};

    	$$self.$inject_state = $$props => {
    		if ('$players' in $$props) players.set($players);
    	};

    	return { formatter, $players, click_handler };
    }

    class PlayersTable_component extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance, create_fragment, safe_not_equal, []);
    		dispatch_dev("SvelteRegisterComponent", { component: this, tagName: "PlayersTable_component", options, id: create_fragment.name });
    	}
    }

    function createCommonjsModule(fn, module) {
    	return module = { exports: {} }, fn(module, module.exports), module.exports;
    }

    var rngBrowser = createCommonjsModule(function (module) {
    // Unique ID creation requires a high quality random # generator.  In the
    // browser this is a little complicated due to unknown quality of Math.random()
    // and inconsistent support for the `crypto` API.  We do the best we can via
    // feature-detection

    // getRandomValues needs to be invoked in a context where "this" is a Crypto
    // implementation. Also, find the complete implementation of crypto on IE11.
    var getRandomValues = (typeof(crypto) != 'undefined' && crypto.getRandomValues && crypto.getRandomValues.bind(crypto)) ||
                          (typeof(msCrypto) != 'undefined' && typeof window.msCrypto.getRandomValues == 'function' && msCrypto.getRandomValues.bind(msCrypto));

    if (getRandomValues) {
      // WHATWG crypto RNG - http://wiki.whatwg.org/wiki/Crypto
      var rnds8 = new Uint8Array(16); // eslint-disable-line no-undef

      module.exports = function whatwgRNG() {
        getRandomValues(rnds8);
        return rnds8;
      };
    } else {
      // Math.random()-based (RNG)
      //
      // If all else fails, use Math.random().  It's fast, but is of unspecified
      // quality.
      var rnds = new Array(16);

      module.exports = function mathRNG() {
        for (var i = 0, r; i < 16; i++) {
          if ((i & 0x03) === 0) r = Math.random() * 0x100000000;
          rnds[i] = r >>> ((i & 0x03) << 3) & 0xff;
        }

        return rnds;
      };
    }
    });

    /**
     * Convert array of 16 byte values to UUID string format of the form:
     * XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX
     */
    var byteToHex = [];
    for (var i = 0; i < 256; ++i) {
      byteToHex[i] = (i + 0x100).toString(16).substr(1);
    }

    function bytesToUuid(buf, offset) {
      var i = offset || 0;
      var bth = byteToHex;
      // join used to fix memory issue caused by concatenation: https://bugs.chromium.org/p/v8/issues/detail?id=3175#c4
      return ([bth[buf[i++]], bth[buf[i++]], 
    	bth[buf[i++]], bth[buf[i++]], '-',
    	bth[buf[i++]], bth[buf[i++]], '-',
    	bth[buf[i++]], bth[buf[i++]], '-',
    	bth[buf[i++]], bth[buf[i++]], '-',
    	bth[buf[i++]], bth[buf[i++]],
    	bth[buf[i++]], bth[buf[i++]],
    	bth[buf[i++]], bth[buf[i++]]]).join('');
    }

    var bytesToUuid_1 = bytesToUuid;

    // **`v1()` - Generate time-based UUID**
    //
    // Inspired by https://github.com/LiosK/UUID.js
    // and http://docs.python.org/library/uuid.html

    var _nodeId;
    var _clockseq;

    // Previous uuid creation time
    var _lastMSecs = 0;
    var _lastNSecs = 0;

    // See https://github.com/broofa/node-uuid for API details
    function v1(options, buf, offset) {
      var i = buf && offset || 0;
      var b = buf || [];

      options = options || {};
      var node = options.node || _nodeId;
      var clockseq = options.clockseq !== undefined ? options.clockseq : _clockseq;

      // node and clockseq need to be initialized to random values if they're not
      // specified.  We do this lazily to minimize issues related to insufficient
      // system entropy.  See #189
      if (node == null || clockseq == null) {
        var seedBytes = rngBrowser();
        if (node == null) {
          // Per 4.5, create and 48-bit node id, (47 random bits + multicast bit = 1)
          node = _nodeId = [
            seedBytes[0] | 0x01,
            seedBytes[1], seedBytes[2], seedBytes[3], seedBytes[4], seedBytes[5]
          ];
        }
        if (clockseq == null) {
          // Per 4.2.2, randomize (14 bit) clockseq
          clockseq = _clockseq = (seedBytes[6] << 8 | seedBytes[7]) & 0x3fff;
        }
      }

      // UUID timestamps are 100 nano-second units since the Gregorian epoch,
      // (1582-10-15 00:00).  JSNumbers aren't precise enough for this, so
      // time is handled internally as 'msecs' (integer milliseconds) and 'nsecs'
      // (100-nanoseconds offset from msecs) since unix epoch, 1970-01-01 00:00.
      var msecs = options.msecs !== undefined ? options.msecs : new Date().getTime();

      // Per 4.2.1.2, use count of uuid's generated during the current clock
      // cycle to simulate higher resolution clock
      var nsecs = options.nsecs !== undefined ? options.nsecs : _lastNSecs + 1;

      // Time since last uuid creation (in msecs)
      var dt = (msecs - _lastMSecs) + (nsecs - _lastNSecs)/10000;

      // Per 4.2.1.2, Bump clockseq on clock regression
      if (dt < 0 && options.clockseq === undefined) {
        clockseq = clockseq + 1 & 0x3fff;
      }

      // Reset nsecs if clock regresses (new clockseq) or we've moved onto a new
      // time interval
      if ((dt < 0 || msecs > _lastMSecs) && options.nsecs === undefined) {
        nsecs = 0;
      }

      // Per 4.2.1.2 Throw error if too many uuids are requested
      if (nsecs >= 10000) {
        throw new Error('uuid.v1(): Can\'t create more than 10M uuids/sec');
      }

      _lastMSecs = msecs;
      _lastNSecs = nsecs;
      _clockseq = clockseq;

      // Per 4.1.4 - Convert from unix epoch to Gregorian epoch
      msecs += 12219292800000;

      // `time_low`
      var tl = ((msecs & 0xfffffff) * 10000 + nsecs) % 0x100000000;
      b[i++] = tl >>> 24 & 0xff;
      b[i++] = tl >>> 16 & 0xff;
      b[i++] = tl >>> 8 & 0xff;
      b[i++] = tl & 0xff;

      // `time_mid`
      var tmh = (msecs / 0x100000000 * 10000) & 0xfffffff;
      b[i++] = tmh >>> 8 & 0xff;
      b[i++] = tmh & 0xff;

      // `time_high_and_version`
      b[i++] = tmh >>> 24 & 0xf | 0x10; // include version
      b[i++] = tmh >>> 16 & 0xff;

      // `clock_seq_hi_and_reserved` (Per 4.2.2 - include variant)
      b[i++] = clockseq >>> 8 | 0x80;

      // `clock_seq_low`
      b[i++] = clockseq & 0xff;

      // `node`
      for (var n = 0; n < 6; ++n) {
        b[i + n] = node[n];
      }

      return buf ? buf : bytesToUuid_1(b);
    }

    var v1_1 = v1;

    /* src/components/PlayerDetails.component.svelte generated by Svelte v3.12.1 */

    const file$1 = "src/components/PlayerDetails.component.svelte";

    function create_fragment$1(ctx) {
    	var div14, a, t0_value = ctx.player.name || 'New player' + "", t0, a_href_value, t1, br0, t2, br1, t3, button0, t5, button1, t7, div13, div0, label0, t9, input0, t10, div1, label1, t12, input1, input1_updating = false, t13, div2, label2, t15, input2, input2_updating = false, t16, div3, label3, t18, input3, input3_updating = false, t19, div4, label4, t21, input4, input4_updating = false, t22, div5, label5, t24, input5, input5_updating = false, t25, div6, label6, t27, input6, input6_updating = false, t28, div7, label7, t30, input7, input7_updating = false, t31, div8, label8, t33, input8, input8_updating = false, t34, div9, label9, t36, input9, input9_updating = false, t37, div10, label10, t39, input10, input10_updating = false, t40, div11, label11, t42, input11, input11_updating = false, t43, div12, label12, t45, input12, input12_updating = false, dispose;

    	function input1_input_handler() {
    		input1_updating = true;
    		ctx.input1_input_handler.call(input1);
    	}

    	function input2_input_handler() {
    		input2_updating = true;
    		ctx.input2_input_handler.call(input2);
    	}

    	function input3_input_handler() {
    		input3_updating = true;
    		ctx.input3_input_handler.call(input3);
    	}

    	function input4_input_handler() {
    		input4_updating = true;
    		ctx.input4_input_handler.call(input4);
    	}

    	function input5_input_handler() {
    		input5_updating = true;
    		ctx.input5_input_handler.call(input5);
    	}

    	function input6_input_handler() {
    		input6_updating = true;
    		ctx.input6_input_handler.call(input6);
    	}

    	function input7_input_handler() {
    		input7_updating = true;
    		ctx.input7_input_handler.call(input7);
    	}

    	function input8_input_handler() {
    		input8_updating = true;
    		ctx.input8_input_handler.call(input8);
    	}

    	function input9_input_handler() {
    		input9_updating = true;
    		ctx.input9_input_handler.call(input9);
    	}

    	function input10_input_handler() {
    		input10_updating = true;
    		ctx.input10_input_handler.call(input10);
    	}

    	function input11_input_handler() {
    		input11_updating = true;
    		ctx.input11_input_handler.call(input11);
    	}

    	function input12_input_handler() {
    		input12_updating = true;
    		ctx.input12_input_handler.call(input12);
    	}

    	const block = {
    		c: function create() {
    			div14 = element("div");
    			a = element("a");
    			t0 = text(t0_value);
    			t1 = space();
    			br0 = element("br");
    			t2 = space();
    			br1 = element("br");
    			t3 = space();
    			button0 = element("button");
    			button0.textContent = "Save changes";
    			t5 = text("    \n    ");
    			button1 = element("button");
    			button1.textContent = "Cancel editing";
    			t7 = space();
    			div13 = element("div");
    			div0 = element("div");
    			label0 = element("label");
    			label0.textContent = "name";
    			t9 = space();
    			input0 = element("input");
    			t10 = space();
    			div1 = element("div");
    			label1 = element("label");
    			label1.textContent = "age";
    			t12 = space();
    			input1 = element("input");
    			t13 = space();
    			div2 = element("div");
    			label2 = element("label");
    			label2.textContent = "defender";
    			t15 = space();
    			input2 = element("input");
    			t16 = space();
    			div3 = element("div");
    			label3 = element("label");
    			label3.textContent = "form";
    			t18 = space();
    			input3 = element("input");
    			t19 = space();
    			div4 = element("div");
    			label4 = element("label");
    			label4.textContent = "keeper";
    			t21 = space();
    			input4 = element("input");
    			t22 = space();
    			div5 = element("div");
    			label5 = element("label");
    			label5.textContent = "pace";
    			t24 = space();
    			input5 = element("input");
    			t25 = space();
    			div6 = element("div");
    			label6 = element("label");
    			label6.textContent = "passing";
    			t27 = space();
    			input6 = element("input");
    			t28 = space();
    			div7 = element("div");
    			label7 = element("label");
    			label7.textContent = "playmaker";
    			t30 = space();
    			input7 = element("input");
    			t31 = space();
    			div8 = element("div");
    			label8 = element("label");
    			label8.textContent = "stamina";
    			t33 = space();
    			input8 = element("input");
    			t34 = space();
    			div9 = element("div");
    			label9 = element("label");
    			label9.textContent = "striker";
    			t36 = space();
    			input9 = element("input");
    			t37 = space();
    			div10 = element("div");
    			label10 = element("label");
    			label10.textContent = "technique";
    			t39 = space();
    			input10 = element("input");
    			t40 = space();
    			div11 = element("div");
    			label11 = element("label");
    			label11.textContent = "value";
    			t42 = space();
    			input11 = element("input");
    			t43 = space();
    			div12 = element("div");
    			label12 = element("label");
    			label12.textContent = "wage";
    			t45 = space();
    			input12 = element("input");
    			attr_dev(a, "class", "player-details-name svelte-psvreh");
    			attr_dev(a, "target", "_blank");
    			attr_dev(a, "href", a_href_value = `http://sokker.org/player/PID/${ctx.player._id}`);
    			add_location(a, file$1, 41, 4, 1292);
    			add_location(br0, file$1, 46, 4, 1461);
    			add_location(br1, file$1, 47, 4, 1471);
    			add_location(button0, file$1, 48, 4, 1481);
    			add_location(button1, file$1, 49, 4, 1563);
    			attr_dev(label0, "for", "name");
    			add_location(label0, file$1, 53, 12, 1697);
    			attr_dev(input0, "type", "text");
    			attr_dev(input0, "placeholder", "name");
    			add_location(input0, file$1, 54, 12, 1740);
    			attr_dev(div0, "class", "svelte-psvreh");
    			add_location(div0, file$1, 52, 8, 1679);
    			attr_dev(label1, "for", "name");
    			add_location(label1, file$1, 57, 12, 1845);
    			attr_dev(input1, "type", "number");
    			attr_dev(input1, "placeholder", "age");
    			add_location(input1, file$1, 58, 11, 1886);
    			attr_dev(div1, "class", "svelte-psvreh");
    			add_location(div1, file$1, 56, 8, 1827);
    			attr_dev(label2, "for", "name");
    			add_location(label2, file$1, 61, 12, 1991);
    			attr_dev(input2, "type", "number");
    			attr_dev(input2, "placeholder", "defender");
    			add_location(input2, file$1, 62, 12, 2038);
    			attr_dev(div2, "class", "svelte-psvreh");
    			add_location(div2, file$1, 60, 8, 1973);
    			attr_dev(label3, "for", "name");
    			add_location(label3, file$1, 65, 12, 2153);
    			attr_dev(input3, "type", "number");
    			attr_dev(input3, "placeholder", "form");
    			add_location(input3, file$1, 66, 12, 2196);
    			attr_dev(div3, "class", "svelte-psvreh");
    			add_location(div3, file$1, 64, 8, 2135);
    			attr_dev(label4, "for", "name");
    			add_location(label4, file$1, 69, 12, 2303);
    			attr_dev(input4, "type", "number");
    			attr_dev(input4, "placeholder", "keeper");
    			add_location(input4, file$1, 70, 12, 2348);
    			attr_dev(div4, "class", "svelte-psvreh");
    			add_location(div4, file$1, 68, 8, 2285);
    			attr_dev(label5, "for", "name");
    			add_location(label5, file$1, 73, 12, 2459);
    			attr_dev(input5, "type", "number");
    			attr_dev(input5, "placeholder", "pace");
    			add_location(input5, file$1, 74, 12, 2502);
    			attr_dev(div5, "class", "svelte-psvreh");
    			add_location(div5, file$1, 72, 8, 2441);
    			attr_dev(label6, "for", "name");
    			add_location(label6, file$1, 77, 12, 2609);
    			attr_dev(input6, "type", "number");
    			attr_dev(input6, "placeholder", "passing");
    			add_location(input6, file$1, 78, 12, 2655);
    			attr_dev(div6, "class", "svelte-psvreh");
    			add_location(div6, file$1, 76, 8, 2591);
    			attr_dev(label7, "for", "name");
    			add_location(label7, file$1, 81, 12, 2768);
    			attr_dev(input7, "type", "number");
    			attr_dev(input7, "placeholder", "playmaker");
    			add_location(input7, file$1, 82, 12, 2816);
    			attr_dev(div7, "class", "svelte-psvreh");
    			add_location(div7, file$1, 80, 8, 2750);
    			attr_dev(label8, "for", "name");
    			add_location(label8, file$1, 85, 12, 2933);
    			attr_dev(input8, "type", "number");
    			attr_dev(input8, "placeholder", "stamina");
    			add_location(input8, file$1, 86, 12, 2979);
    			attr_dev(div8, "class", "svelte-psvreh");
    			add_location(div8, file$1, 84, 8, 2915);
    			attr_dev(label9, "for", "name");
    			add_location(label9, file$1, 89, 12, 3092);
    			attr_dev(input9, "type", "number");
    			attr_dev(input9, "placeholder", "striker");
    			add_location(input9, file$1, 90, 11, 3137);
    			attr_dev(div9, "class", "svelte-psvreh");
    			add_location(div9, file$1, 88, 8, 3074);
    			attr_dev(label10, "for", "name");
    			add_location(label10, file$1, 93, 12, 3250);
    			attr_dev(input10, "type", "number");
    			attr_dev(input10, "placeholder", "technique");
    			add_location(input10, file$1, 94, 11, 3297);
    			attr_dev(div10, "class", "svelte-psvreh");
    			add_location(div10, file$1, 92, 8, 3232);
    			attr_dev(label11, "for", "name");
    			add_location(label11, file$1, 97, 12, 3414);
    			attr_dev(input11, "type", "number");
    			attr_dev(input11, "placeholder", "value");
    			add_location(input11, file$1, 98, 12, 3458);
    			attr_dev(div11, "class", "svelte-psvreh");
    			add_location(div11, file$1, 96, 8, 3396);
    			attr_dev(label12, "for", "name");
    			add_location(label12, file$1, 101, 12, 3567);
    			attr_dev(input12, "type", "number");
    			attr_dev(input12, "placeholder", "wage");
    			add_location(input12, file$1, 102, 12, 3610);
    			attr_dev(div12, "class", "svelte-psvreh");
    			add_location(div12, file$1, 100, 8, 3549);
    			attr_dev(div13, "class", "player-details-form svelte-psvreh");
    			add_location(div13, file$1, 51, 4, 1637);
    			attr_dev(div14, "class", "player-details svelte-psvreh");
    			add_location(div14, file$1, 40, 0, 1259);

    			dispose = [
    				listen_dev(button0, "click", ctx.onSavePlayer),
    				listen_dev(button1, "click", ctx.click_handler),
    				listen_dev(input0, "input", ctx.input0_input_handler),
    				listen_dev(input1, "input", input1_input_handler),
    				listen_dev(input2, "input", input2_input_handler),
    				listen_dev(input3, "input", input3_input_handler),
    				listen_dev(input4, "input", input4_input_handler),
    				listen_dev(input5, "input", input5_input_handler),
    				listen_dev(input6, "input", input6_input_handler),
    				listen_dev(input7, "input", input7_input_handler),
    				listen_dev(input8, "input", input8_input_handler),
    				listen_dev(input9, "input", input9_input_handler),
    				listen_dev(input10, "input", input10_input_handler),
    				listen_dev(input11, "input", input11_input_handler),
    				listen_dev(input12, "input", input12_input_handler)
    			];
    		},

    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			insert_dev(target, div14, anchor);
    			append_dev(div14, a);
    			append_dev(a, t0);
    			append_dev(div14, t1);
    			append_dev(div14, br0);
    			append_dev(div14, t2);
    			append_dev(div14, br1);
    			append_dev(div14, t3);
    			append_dev(div14, button0);
    			append_dev(div14, t5);
    			append_dev(div14, button1);
    			append_dev(div14, t7);
    			append_dev(div14, div13);
    			append_dev(div13, div0);
    			append_dev(div0, label0);
    			append_dev(div0, t9);
    			append_dev(div0, input0);

    			set_input_value(input0, ctx.form.name);

    			append_dev(div13, t10);
    			append_dev(div13, div1);
    			append_dev(div1, label1);
    			append_dev(div1, t12);
    			append_dev(div1, input1);

    			set_input_value(input1, ctx.form.age);

    			append_dev(div13, t13);
    			append_dev(div13, div2);
    			append_dev(div2, label2);
    			append_dev(div2, t15);
    			append_dev(div2, input2);

    			set_input_value(input2, ctx.form.defender);

    			append_dev(div13, t16);
    			append_dev(div13, div3);
    			append_dev(div3, label3);
    			append_dev(div3, t18);
    			append_dev(div3, input3);

    			set_input_value(input3, ctx.form.form);

    			append_dev(div13, t19);
    			append_dev(div13, div4);
    			append_dev(div4, label4);
    			append_dev(div4, t21);
    			append_dev(div4, input4);

    			set_input_value(input4, ctx.form.keeper);

    			append_dev(div13, t22);
    			append_dev(div13, div5);
    			append_dev(div5, label5);
    			append_dev(div5, t24);
    			append_dev(div5, input5);

    			set_input_value(input5, ctx.form.pace);

    			append_dev(div13, t25);
    			append_dev(div13, div6);
    			append_dev(div6, label6);
    			append_dev(div6, t27);
    			append_dev(div6, input6);

    			set_input_value(input6, ctx.form.passing);

    			append_dev(div13, t28);
    			append_dev(div13, div7);
    			append_dev(div7, label7);
    			append_dev(div7, t30);
    			append_dev(div7, input7);

    			set_input_value(input7, ctx.form.playmaker);

    			append_dev(div13, t31);
    			append_dev(div13, div8);
    			append_dev(div8, label8);
    			append_dev(div8, t33);
    			append_dev(div8, input8);

    			set_input_value(input8, ctx.form.stamina);

    			append_dev(div13, t34);
    			append_dev(div13, div9);
    			append_dev(div9, label9);
    			append_dev(div9, t36);
    			append_dev(div9, input9);

    			set_input_value(input9, ctx.form.striker);

    			append_dev(div13, t37);
    			append_dev(div13, div10);
    			append_dev(div10, label10);
    			append_dev(div10, t39);
    			append_dev(div10, input10);

    			set_input_value(input10, ctx.form.technique);

    			append_dev(div13, t40);
    			append_dev(div13, div11);
    			append_dev(div11, label11);
    			append_dev(div11, t42);
    			append_dev(div11, input11);

    			set_input_value(input11, ctx.form.value);

    			append_dev(div13, t43);
    			append_dev(div13, div12);
    			append_dev(div12, label12);
    			append_dev(div12, t45);
    			append_dev(div12, input12);

    			set_input_value(input12, ctx.form.wage);
    		},

    		p: function update(changed, ctx) {
    			if ((changed.player) && t0_value !== (t0_value = ctx.player.name || 'New player' + "")) {
    				set_data_dev(t0, t0_value);
    			}

    			if ((changed.player) && a_href_value !== (a_href_value = `http://sokker.org/player/PID/${ctx.player._id}`)) {
    				attr_dev(a, "href", a_href_value);
    			}

    			if (changed.form && (input0.value !== ctx.form.name)) set_input_value(input0, ctx.form.name);
    			if (!input1_updating && changed.form) set_input_value(input1, ctx.form.age);
    			input1_updating = false;
    			if (!input2_updating && changed.form) set_input_value(input2, ctx.form.defender);
    			input2_updating = false;
    			if (!input3_updating && changed.form) set_input_value(input3, ctx.form.form);
    			input3_updating = false;
    			if (!input4_updating && changed.form) set_input_value(input4, ctx.form.keeper);
    			input4_updating = false;
    			if (!input5_updating && changed.form) set_input_value(input5, ctx.form.pace);
    			input5_updating = false;
    			if (!input6_updating && changed.form) set_input_value(input6, ctx.form.passing);
    			input6_updating = false;
    			if (!input7_updating && changed.form) set_input_value(input7, ctx.form.playmaker);
    			input7_updating = false;
    			if (!input8_updating && changed.form) set_input_value(input8, ctx.form.stamina);
    			input8_updating = false;
    			if (!input9_updating && changed.form) set_input_value(input9, ctx.form.striker);
    			input9_updating = false;
    			if (!input10_updating && changed.form) set_input_value(input10, ctx.form.technique);
    			input10_updating = false;
    			if (!input11_updating && changed.form) set_input_value(input11, ctx.form.value);
    			input11_updating = false;
    			if (!input12_updating && changed.form) set_input_value(input12, ctx.form.wage);
    			input12_updating = false;
    		},

    		i: noop,
    		o: noop,

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach_dev(div14);
    			}

    			run_all(dispose);
    		}
    	};
    	dispatch_dev("SvelteRegisterBlock", { block, id: create_fragment$1.name, type: "component", source: "", ctx });
    	return block;
    }

    function instance$1($$self, $$props, $$invalidate) {
    	let $players;

    	validate_store(players, 'players');
    	component_subscribe($$self, players, $$value => { $players = $$value; $$invalidate('$players', $players); });

    	

        let form = { };

        onMount(()=> {
            $$invalidate('form', form = player);
            players.subscribe((players)=> {
                $$invalidate('form', form = $players.all.find(player => player.firebaseId === $players.selected) || { name: '', country: 'UA' });
            });
        });

        const onSavePlayer = ()=> {
            const firebaseId = player.firebaseId || v1_1();
            const firebasePlayerDoc = FIRESTORE.players.doc(firebaseId);

            firebasePlayerDoc.get().then(doc => {
                firebasePlayerDoc.set(form)
                    .then(function(p) {
                        if(doc.exists) {
                            players.updatePlayer({ ...form , firebaseId : player.firebaseId });
                        } else {
                            players.add({ ...form, firebaseId });
                        }
                        players.select(null);
                    })
                    .catch(function(error) {
                        alert("Player save error: ", error);
                    });
            });
        };

    	const click_handler = () => players.select(null);

    	function input0_input_handler() {
    		form.name = this.value;
    		$$invalidate('form', form);
    	}

    	function input1_input_handler() {
    		form.age = to_number(this.value);
    		$$invalidate('form', form);
    	}

    	function input2_input_handler() {
    		form.defender = to_number(this.value);
    		$$invalidate('form', form);
    	}

    	function input3_input_handler() {
    		form.form = to_number(this.value);
    		$$invalidate('form', form);
    	}

    	function input4_input_handler() {
    		form.keeper = to_number(this.value);
    		$$invalidate('form', form);
    	}

    	function input5_input_handler() {
    		form.pace = to_number(this.value);
    		$$invalidate('form', form);
    	}

    	function input6_input_handler() {
    		form.passing = to_number(this.value);
    		$$invalidate('form', form);
    	}

    	function input7_input_handler() {
    		form.playmaker = to_number(this.value);
    		$$invalidate('form', form);
    	}

    	function input8_input_handler() {
    		form.stamina = to_number(this.value);
    		$$invalidate('form', form);
    	}

    	function input9_input_handler() {
    		form.striker = to_number(this.value);
    		$$invalidate('form', form);
    	}

    	function input10_input_handler() {
    		form.technique = to_number(this.value);
    		$$invalidate('form', form);
    	}

    	function input11_input_handler() {
    		form.value = to_number(this.value);
    		$$invalidate('form', form);
    	}

    	function input12_input_handler() {
    		form.wage = to_number(this.value);
    		$$invalidate('form', form);
    	}

    	$$self.$capture_state = () => {
    		return {};
    	};

    	$$self.$inject_state = $$props => {
    		if ('form' in $$props) $$invalidate('form', form = $$props.form);
    		if ('player' in $$props) $$invalidate('player', player = $$props.player);
    		if ('$players' in $$props) players.set($players);
    	};

    	let player;

    	$$self.$$.update = ($$dirty = { $players: 1 }) => {
    		if ($$dirty.$players) { $$invalidate('player', player = $players.all.find(player => player.firebaseId === $players.selected) || { }); }
    	};

    	return {
    		form,
    		onSavePlayer,
    		player,
    		click_handler,
    		input0_input_handler,
    		input1_input_handler,
    		input2_input_handler,
    		input3_input_handler,
    		input4_input_handler,
    		input5_input_handler,
    		input6_input_handler,
    		input7_input_handler,
    		input8_input_handler,
    		input9_input_handler,
    		input10_input_handler,
    		input11_input_handler,
    		input12_input_handler
    	};
    }

    class PlayerDetails_component extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$1, create_fragment$1, safe_not_equal, []);
    		dispatch_dev("SvelteRegisterComponent", { component: this, tagName: "PlayerDetails_component", options, id: create_fragment$1.name });
    	}
    }

    /* src/components/Players.component.svelte generated by Svelte v3.12.1 */

    const file$2 = "src/components/Players.component.svelte";

    // (18:4) { #if $players.selected }
    function create_if_block(ctx) {
    	var div, current;

    	var playerdetails = new PlayerDetails_component({ $$inline: true });

    	const block = {
    		c: function create() {
    			div = element("div");
    			playerdetails.$$.fragment.c();
    			attr_dev(div, "class", "player-details-wrapper svelte-pmz1li");
    			add_location(div, file$2, 18, 8, 393);
    		},

    		m: function mount(target, anchor) {
    			insert_dev(target, div, anchor);
    			mount_component(playerdetails, div, null);
    			current = true;
    		},

    		i: function intro(local) {
    			if (current) return;
    			transition_in(playerdetails.$$.fragment, local);

    			current = true;
    		},

    		o: function outro(local) {
    			transition_out(playerdetails.$$.fragment, local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach_dev(div);
    			}

    			destroy_component(playerdetails);
    		}
    	};
    	dispatch_dev("SvelteRegisterBlock", { block, id: create_if_block.name, type: "if", source: "(18:4) { if_1 $players.selected }", ctx });
    	return block;
    }

    function create_fragment$2(ctx) {
    	var div1, div0, div0_class_value, t, current;

    	var playerstable = new PlayersTable_component({ $$inline: true });

    	var if_block = (ctx.$players.selected) && create_if_block(ctx);

    	const block = {
    		c: function create() {
    			div1 = element("div");
    			div0 = element("div");
    			playerstable.$$.fragment.c();
    			t = space();
    			if (if_block) if_block.c();
    			attr_dev(div0, "class", div0_class_value = "" + null_to_empty((ctx.$players.selected ? "short" : "long")) + " svelte-pmz1li");
    			add_location(div0, file$2, 12, 4, 262);
    			attr_dev(div1, "class", "players svelte-pmz1li");
    			add_location(div1, file$2, 10, 0, 235);
    		},

    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			insert_dev(target, div1, anchor);
    			append_dev(div1, div0);
    			mount_component(playerstable, div0, null);
    			append_dev(div1, t);
    			if (if_block) if_block.m(div1, null);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			if ((!current || changed.$players) && div0_class_value !== (div0_class_value = "" + null_to_empty((ctx.$players.selected ? "short" : "long")) + " svelte-pmz1li")) {
    				attr_dev(div0, "class", div0_class_value);
    			}

    			if (ctx.$players.selected) {
    				if (!if_block) {
    					if_block = create_if_block(ctx);
    					if_block.c();
    					transition_in(if_block, 1);
    					if_block.m(div1, null);
    				} else transition_in(if_block, 1);
    			} else if (if_block) {
    				group_outros();
    				transition_out(if_block, 1, 1, () => {
    					if_block = null;
    				});
    				check_outros();
    			}
    		},

    		i: function intro(local) {
    			if (current) return;
    			transition_in(playerstable.$$.fragment, local);

    			transition_in(if_block);
    			current = true;
    		},

    		o: function outro(local) {
    			transition_out(playerstable.$$.fragment, local);
    			transition_out(if_block);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach_dev(div1);
    			}

    			destroy_component(playerstable);

    			if (if_block) if_block.d();
    		}
    	};
    	dispatch_dev("SvelteRegisterBlock", { block, id: create_fragment$2.name, type: "component", source: "", ctx });
    	return block;
    }

    function instance$2($$self, $$props, $$invalidate) {
    	let $players;

    	validate_store(players, 'players');
    	component_subscribe($$self, players, $$value => { $players = $$value; $$invalidate('$players', $players); });

    	$$self.$capture_state = () => {
    		return {};
    	};

    	$$self.$inject_state = $$props => {
    		if ('$players' in $$props) players.set($players);
    	};

    	return { $players };
    }

    class Players_component extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$2, create_fragment$2, safe_not_equal, []);
    		dispatch_dev("SvelteRegisterComponent", { component: this, tagName: "Players_component", options, id: create_fragment$2.name });
    	}
    }

    function fade(node, { delay = 0, duration = 400 }) {
        const o = +getComputedStyle(node).opacity;
        return {
            delay,
            duration,
            css: t => `opacity: ${t * o}`
        };
    }

    /* src/components/LoginForm.component.svelte generated by Svelte v3.12.1 */

    const file$3 = "src/components/LoginForm.component.svelte";

    // (39:12) { #if errorMsg }
    function create_if_block$1(ctx) {
    	var p, t;

    	const block = {
    		c: function create() {
    			p = element("p");
    			t = text(ctx.errorMsg);
    			attr_dev(p, "class", "error-msg svelte-v5mphi");
    			add_location(p, file$3, 39, 16, 1023);
    		},

    		m: function mount(target, anchor) {
    			insert_dev(target, p, anchor);
    			append_dev(p, t);
    		},

    		p: function update(changed, ctx) {
    			if (changed.errorMsg) {
    				set_data_dev(t, ctx.errorMsg);
    			}
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach_dev(p);
    			}
    		}
    	};
    	dispatch_dev("SvelteRegisterBlock", { block, id: create_if_block$1.name, type: "if", source: "(39:12) { if_1 errorMsg }", ctx });
    	return block;
    }

    function create_fragment$3(ctx) {
    	var div3, div0, t0, div1, t1, div2, form_1, input0, t2, input1, t3, button, t4, button_disabled_value, t5, div3_transition, current, dispose;

    	var if_block = (ctx.errorMsg) && create_if_block$1(ctx);

    	const block = {
    		c: function create() {
    			div3 = element("div");
    			div0 = element("div");
    			t0 = space();
    			div1 = element("div");
    			t1 = space();
    			div2 = element("div");
    			form_1 = element("form");
    			input0 = element("input");
    			t2 = space();
    			input1 = element("input");
    			t3 = space();
    			button = element("button");
    			t4 = text("Login");
    			t5 = space();
    			if (if_block) if_block.c();
    			attr_dev(div0, "class", "logo svelte-v5mphi");
    			add_location(div0, file$3, 28, 4, 611);
    			attr_dev(div1, "class", "divider svelte-v5mphi");
    			add_location(div1, file$3, 30, 4, 637);
    			attr_dev(input0, "type", "text");
    			attr_dev(input0, "placeholder", "email");
    			add_location(input0, file$3, 34, 12, 733);
    			attr_dev(input1, "type", "password");
    			attr_dev(input1, "placeholder", "password");
    			add_location(input1, file$3, 35, 12, 811);
    			attr_dev(button, "type", "submit");
    			button.disabled = button_disabled_value = !ctx.form.email || !ctx.form.password;
    			add_location(button, file$3, 36, 12, 899);
    			attr_dev(form_1, "class", "svelte-v5mphi");
    			add_location(form_1, file$3, 33, 8, 693);
    			attr_dev(div2, "class", "form svelte-v5mphi");
    			add_location(div2, file$3, 32, 4, 666);
    			attr_dev(div3, "class", "login svelte-v5mphi");
    			add_location(div3, file$3, 26, 0, 570);

    			dispose = [
    				listen_dev(input0, "input", ctx.input0_input_handler),
    				listen_dev(input1, "input", ctx.input1_input_handler),
    				listen_dev(form_1, "submit", ctx.onSubmit)
    			];
    		},

    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			insert_dev(target, div3, anchor);
    			append_dev(div3, div0);
    			append_dev(div3, t0);
    			append_dev(div3, div1);
    			append_dev(div3, t1);
    			append_dev(div3, div2);
    			append_dev(div2, form_1);
    			append_dev(form_1, input0);

    			set_input_value(input0, ctx.form.email);

    			append_dev(form_1, t2);
    			append_dev(form_1, input1);

    			set_input_value(input1, ctx.form.password);

    			append_dev(form_1, t3);
    			append_dev(form_1, button);
    			append_dev(button, t4);
    			append_dev(form_1, t5);
    			if (if_block) if_block.m(form_1, null);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			if (changed.form && (input0.value !== ctx.form.email)) set_input_value(input0, ctx.form.email);
    			if (changed.form && (input1.value !== ctx.form.password)) set_input_value(input1, ctx.form.password);

    			if ((!current || changed.form) && button_disabled_value !== (button_disabled_value = !ctx.form.email || !ctx.form.password)) {
    				prop_dev(button, "disabled", button_disabled_value);
    			}

    			if (ctx.errorMsg) {
    				if (if_block) {
    					if_block.p(changed, ctx);
    				} else {
    					if_block = create_if_block$1(ctx);
    					if_block.c();
    					if_block.m(form_1, null);
    				}
    			} else if (if_block) {
    				if_block.d(1);
    				if_block = null;
    			}
    		},

    		i: function intro(local) {
    			if (current) return;
    			add_render_callback(() => {
    				if (!div3_transition) div3_transition = create_bidirectional_transition(div3, fade, {}, true);
    				div3_transition.run(1);
    			});

    			current = true;
    		},

    		o: function outro(local) {
    			if (!div3_transition) div3_transition = create_bidirectional_transition(div3, fade, {}, false);
    			div3_transition.run(0);

    			current = false;
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach_dev(div3);
    			}

    			if (if_block) if_block.d();

    			if (detaching) {
    				if (div3_transition) div3_transition.end();
    			}

    			run_all(dispose);
    		}
    	};
    	dispatch_dev("SvelteRegisterBlock", { block, id: create_fragment$3.name, type: "component", source: "", ctx });
    	return block;
    }

    function instance$3($$self, $$props, $$invalidate) {
    	

        let form = {
            email: '',
            password: ''
        };

        let errorMsg = null;

        const onSubmit = (e)=> {
            e.preventDefault();

            $$invalidate('errorMsg', errorMsg = null);

            window.firebase.auth().signInWithEmailAndPassword(form.email, form.password)
                .then((a)=> {
                    user.signIn(window.firebase.auth().currentUser);
                }).catch((e)=> {
                    $$invalidate('errorMsg', errorMsg = e.message);
                });
        };

    	function input0_input_handler() {
    		form.email = this.value;
    		$$invalidate('form', form);
    	}

    	function input1_input_handler() {
    		form.password = this.value;
    		$$invalidate('form', form);
    	}

    	$$self.$capture_state = () => {
    		return {};
    	};

    	$$self.$inject_state = $$props => {
    		if ('form' in $$props) $$invalidate('form', form = $$props.form);
    		if ('errorMsg' in $$props) $$invalidate('errorMsg', errorMsg = $$props.errorMsg);
    	};

    	return {
    		form,
    		errorMsg,
    		onSubmit,
    		input0_input_handler,
    		input1_input_handler
    	};
    }

    class LoginForm_component extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$3, create_fragment$3, safe_not_equal, []);
    		dispatch_dev("SvelteRegisterComponent", { component: this, tagName: "LoginForm_component", options, id: create_fragment$3.name });
    	}
    }

    /* src/App.svelte generated by Svelte v3.12.1 */

    const file$4 = "src/App.svelte";

    // (22:1) {#if mounted && $user === null }
    function create_if_block_1(ctx) {
    	var current;

    	var loginform = new LoginForm_component({ $$inline: true });

    	const block = {
    		c: function create() {
    			loginform.$$.fragment.c();
    		},

    		m: function mount(target, anchor) {
    			mount_component(loginform, target, anchor);
    			current = true;
    		},

    		i: function intro(local) {
    			if (current) return;
    			transition_in(loginform.$$.fragment, local);

    			current = true;
    		},

    		o: function outro(local) {
    			transition_out(loginform.$$.fragment, local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			destroy_component(loginform, detaching);
    		}
    	};
    	dispatch_dev("SvelteRegisterBlock", { block, id: create_if_block_1.name, type: "if", source: "(22:1) {#if mounted && $user === null }", ctx });
    	return block;
    }

    // (26:1) {#if mounted && $user }
    function create_if_block$2(ctx) {
    	var current;

    	var players = new Players_component({ $$inline: true });

    	const block = {
    		c: function create() {
    			players.$$.fragment.c();
    		},

    		m: function mount(target, anchor) {
    			mount_component(players, target, anchor);
    			current = true;
    		},

    		i: function intro(local) {
    			if (current) return;
    			transition_in(players.$$.fragment, local);

    			current = true;
    		},

    		o: function outro(local) {
    			transition_out(players.$$.fragment, local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			destroy_component(players, detaching);
    		}
    	};
    	dispatch_dev("SvelteRegisterBlock", { block, id: create_if_block$2.name, type: "if", source: "(26:1) {#if mounted && $user }", ctx });
    	return block;
    }

    function create_fragment$4(ctx) {
    	var div, t, current;

    	var if_block0 = (ctx.mounted && ctx.$user === null) && create_if_block_1(ctx);

    	var if_block1 = (ctx.mounted && ctx.$user) && create_if_block$2(ctx);

    	const block = {
    		c: function create() {
    			div = element("div");
    			if (if_block0) if_block0.c();
    			t = space();
    			if (if_block1) if_block1.c();
    			attr_dev(div, "class", "content svelte-12f9bbn");
    			add_location(div, file$4, 20, 0, 433);
    		},

    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			insert_dev(target, div, anchor);
    			if (if_block0) if_block0.m(div, null);
    			append_dev(div, t);
    			if (if_block1) if_block1.m(div, null);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			if (ctx.mounted && ctx.$user === null) {
    				if (!if_block0) {
    					if_block0 = create_if_block_1(ctx);
    					if_block0.c();
    					transition_in(if_block0, 1);
    					if_block0.m(div, t);
    				} else transition_in(if_block0, 1);
    			} else if (if_block0) {
    				group_outros();
    				transition_out(if_block0, 1, 1, () => {
    					if_block0 = null;
    				});
    				check_outros();
    			}

    			if (ctx.mounted && ctx.$user) {
    				if (!if_block1) {
    					if_block1 = create_if_block$2(ctx);
    					if_block1.c();
    					transition_in(if_block1, 1);
    					if_block1.m(div, null);
    				} else transition_in(if_block1, 1);
    			} else if (if_block1) {
    				group_outros();
    				transition_out(if_block1, 1, 1, () => {
    					if_block1 = null;
    				});
    				check_outros();
    			}
    		},

    		i: function intro(local) {
    			if (current) return;
    			transition_in(if_block0);
    			transition_in(if_block1);
    			current = true;
    		},

    		o: function outro(local) {
    			transition_out(if_block0);
    			transition_out(if_block1);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach_dev(div);
    			}

    			if (if_block0) if_block0.d();
    			if (if_block1) if_block1.d();
    		}
    	};
    	dispatch_dev("SvelteRegisterBlock", { block, id: create_fragment$4.name, type: "component", source: "", ctx });
    	return block;
    }

    function instance$4($$self, $$props, $$invalidate) {
    	let $user;

    	validate_store(user, 'user');
    	component_subscribe($$self, user, $$value => { $user = $$value; $$invalidate('$user', $user); });

    	

    	let mounted = false;

    	firebase.auth().onAuthStateChanged(function(firebaseUser) {
    		if (firebaseUser) {
    			user.signIn(firebaseUser);
    			$$invalidate('mounted', mounted = true);
    		} else {
    			user.signOut();
    			$$invalidate('mounted', mounted = true);
    		}
    	});

    	$$self.$capture_state = () => {
    		return {};
    	};

    	$$self.$inject_state = $$props => {
    		if ('mounted' in $$props) $$invalidate('mounted', mounted = $$props.mounted);
    		if ('$user' in $$props) user.set($user);
    	};

    	return { mounted, $user };
    }

    class App extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$4, create_fragment$4, safe_not_equal, []);
    		dispatch_dev("SvelteRegisterComponent", { component: this, tagName: "App", options, id: create_fragment$4.name });
    	}
    }

    var app = new App({
    	target: document.body
    });

    return app;

}());
//# sourceMappingURL=bundle.js.map
